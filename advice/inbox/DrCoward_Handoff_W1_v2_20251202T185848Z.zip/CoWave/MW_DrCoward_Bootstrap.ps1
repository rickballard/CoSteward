
MW DrCoward Bootstrap

Stop='Stop'; Set-StrictMode -Version Latest
Write-Host 'Open INTENT/triage.md and follow W1. See CoWave/MW_CoCloud_Wave.ps1 for automation.'
