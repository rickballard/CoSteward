Look in:

CoCivium: docs/intent/advice/notes/20251202/CoSync_*

CoPolitic: docs/intent/advice/notes/20251202/CoSync_* and Handoff_To_CoPolitic20251201_*

GIBindex: PR adding CoCloud term family to terms/pending/*
