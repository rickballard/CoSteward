GovAI, Carnegie, OECD.AI, NIST, CHAI, MIT Media Lab, Citizen Lab, OII, Skoll, OSF, Gates (policy), Emerson, GitHub, Anthropic, OpenAI alignment, Redwood, RAND, Max Barry, Bret Victor.
