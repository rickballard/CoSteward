
Install trailer/noise guards.

Convert 4 stubs in examples/ to live trailers.

Build/commit CoCloud_Map.md on PRs touching .cotrail.*.

Add .conoise. with budget/window/rollback.

Wire CoPolitic site section and DOI banner hook.

CoBus note after merges; link receipts.

Outreach: ship Reviewer Pack.
