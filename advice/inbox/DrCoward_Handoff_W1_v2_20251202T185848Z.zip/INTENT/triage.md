P0: guards green on main; map regenerates; Reviewer Pack public.
P1: CoPolitic section live; CoBus broadcast to CoPrime/Co1/CoSteward.
P2: 2 caselets from Human-Interest v4; extend trailer schema with receipts/rollback fields.
