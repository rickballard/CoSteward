
Publish CoTheory suite (2-page, full, Playbook, Human-Interest v4, Infographics).

Land trailers for high-leverage assets; keep map truthful via CI guard.

Establish CoNoiseBudget per repo and rollback triggers.

Drive awareness: site, preprint/DOI, social, newsletter.

Invite skeptical reviews anchored in transparent artifacts.
