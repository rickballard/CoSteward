
Trailer density vs truthfulness; minimum viable coverage per repo.

Noise vs merge velocity; tune CoNoiseBudget.

Mythos leverage: CoGodspawn / CoScendence in narratives.

Edge-owned governance exemplars vs centralized policy.

Academic conduit: mirror to Zenodo/OSF; reviewer-friendly outline.

Controversy catalysts: 5 falsifiable claims with civility.

Repo sweeps: CoMeld/CoPrune orphans; diagram promotion/prune.

Outreach A/B: 'AI-facing websites' vs 'CoPortals' vs 'Civic guardrails'.

Metrics: node count, trailer coverage %, reviewer count, DOI cites, signups.

Align to: CoIndex/docs/CoTheoryCivilization/AcademiaShock_Handoff_v3.md.
