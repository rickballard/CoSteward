Tracks: Preprint/DOI, Site, Social, Newsletter.
Reviewer Pack: 2-page (PDF+MD), Infographics, Playbook excerpt, link index, how-to-review.
