# Handoff -> DrCoward — Wave W1 (20251202T181811Z)

Intent: receive the CoTheory/CoCloud publication suite and push to publication & controversy. Repo-first, CoBus-first.

Quick Start
1) Run CoWave/MW_DrCoward_Bootstrap.ps1 in PS7.
2) Execute INTENT/triage.md DO-blocks.
3) Use CoBus/Broadcast_DrCoward_W0.md to ping sibling sessions after merges.

Contents
- tools/: validators + map indexer + advicebomb helper
- schemas/: JSON Schemas
- examples/: sample + 4 trailer stubs
- CoWave/: orchestration scripts (MW_*)
- INTENT/: intents, actions, triage, research agenda, publication plan, outreach
- CoBus/: broadcast template
- site/: cocloud.html seed
- RECEIPTS/: history summary and CoBus pointers

Status (CoBloat): CU SOFT | PU SOFT | HU OK | WT SOFT
