
CoSync — 20251202T181811Z

Wave: DrCoward bootstrap — CoCloud/CoTrailer guards live; stubs seeded; CoCloud map rebuilt; AdviceBomb dropped to CoPolitic.
Next: add live .cotrail.* to 5 assets; open 1 CoMeld + 1 CoPrune; wire site nav; push DOI banner when available.
Receipts: repo histories around this timestamp and advice/INBOX_LOG.md.
