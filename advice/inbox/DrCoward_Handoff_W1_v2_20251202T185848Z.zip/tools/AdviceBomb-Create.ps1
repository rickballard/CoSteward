param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$RepoPath)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ts = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$inbox = Join-Path $RepoPath 'advice\inbox'; New-Item -ItemType Directory -Force -Path $inbox *> $null
$zip = Join-Path $inbox ("AdviceBomb_{0}.zip" -f $ts)
[System.IO.Compression.ZipFile]::CreateFromDirectory($Source,$zip)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$fs = [System.IO.File]::OpenRead($zip)
$hash = ($sha256.ComputeHash($fs) | ForEach-Object { $_.ToString('x2') }) -join ''; $fs.Close()
Set-Content -Path ($zip + '.sha256') -Value $hash -Encoding ASCII
$log = Join-Path $RepoPath 'advice\INBOX_LOG.md'
Add-Content -Path $log -Value ("{0} {1} sha256:{2}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), (Split-Path $zip -Leaf), $hash)
Write-Host ("AdviceBomb -> {0}`nsha256:{1}" -f $zip, $hash)
