# CoTrellis Seed Evolution Guide (Full Version v3)

## Purpose
Prevent bloat and guide seed-phase evolution into stable v1 assets.

## Criteria
- Clarity.
- Small scope.
- Stopping conditions.
- A clear trail for follow-up waves.
