# Priority Window Plan

Filing date anchor: set by the first Canadian filing.

Within 6 months of the Canada filing date
- United States: file word mark in Class 42 (intent to use if needed)
- Optional Madrid through CIPO as office of origin: designate EU, UK, AU

Operational notes
- Keep goods and services close to the Canada wording
- Track deadlines in a shared calendar
- Store all receipts and later assignments in the repo legal folder
- This plan created at 2025-11-19 01:37:13Z
