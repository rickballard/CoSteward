# CoDialogue Bar Chart UI v0.2

## Example Display

```
Clarity:                ███████████░░  72
Evidence Use:           ████░░░░░░░░░  31
Openness to Challenge:  ███████░░░░░░  56
Curiosity:              ████████████░  87
Self-Correction:        ███░░░░░░░░░░  22
CoEvo Posture:          ████████░░░░░  64
Tribal Signal Level:    ███░░░░░░░░░░  28 (lower = better)
```

## Requirements
- Non-judgmental  
- Collapsible  
- Exportable to CoAudit  
