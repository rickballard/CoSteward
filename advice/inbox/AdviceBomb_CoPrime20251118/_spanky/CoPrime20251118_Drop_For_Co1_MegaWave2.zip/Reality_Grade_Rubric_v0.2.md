# Reality Grade Rubric v0.2

## Metrics (0–100)
1. Clarity  
2. Evidence Use  
3. Openness to Challenge  
4. Curiosity  
5. Self-Correction  
6. CoEvolution Posture  
7. Tribal Signal Level (lower is better)

## Properties
- Transparent and explainable.  
- Retroactively upgradable.  
- Exportable to CoAudit.
