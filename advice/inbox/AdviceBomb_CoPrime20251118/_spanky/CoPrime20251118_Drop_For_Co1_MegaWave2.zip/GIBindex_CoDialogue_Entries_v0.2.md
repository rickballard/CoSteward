# GIBindex Entries – CoDialogue Suite v0.2

## CoDialogue  
Dialogue-governance layer enabling structured preference evolution.

## CoNudge  
Pattern detection → human approval → stabilization.

## Reality Grade  
Reflective, multi-metric reasoning quality scoring.

## Bar Chart Feedback  
UI reflection tool for quick self-awareness.

## CoEvolution Guardrail  
Guided challenge to prevent harmful drift.
