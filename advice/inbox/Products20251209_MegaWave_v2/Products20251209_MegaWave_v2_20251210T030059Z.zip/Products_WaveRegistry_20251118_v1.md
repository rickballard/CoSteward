# Advisory from session labelled "Products20291128" for Co1 session labelled "CoPrime20251128" – ProductsRails Wave 3 (Products20251128)

**Context**

Products20291128 session pushed ProductsRails Wave 3 (W3) into repos, treating CoSuite products as civic-scale infrastructure rather than just tools.

Key repos/PRs:

- CoSteward:
  - PR #203 `docs/cocachelocal layout 20251128T172241`
  - Adds:
    - `docs/intent/products/MW_ProductsRails_W3_README_v1.md`
    - `docs/intent/products/Products_Rails_EvolutionPlan_W3_v1.md`
    - `docs/intent/products/CoSuite_ProductSafety_Guardrails_W3_v1.md`
    - Updated `docs/intent/CoStatus_Pulses_v1.md` with a Products20251128 pulse

- CoAgent:
  - PR #137 `docs: CoArena medals/ref MVP + PTAG W2/W3 rails`
  - Branch `docs/coarena-medalsandref-mvp-20251128T094135Z`
  - Adds:
    - `docs/coarena/CoArena_Productization_Rails_W2_v1.md`
    - `docs/coarena/CoArena_PTAG_W3_Overlay_v1.md` (localizing W3 P/T/A/G lens for CoArena)

---

## What W3 establishes

1. **P/T/A/G maturity grid (0–3) for all products**

- P – Productization
- T – Technical
- A – AI
- G – Governance

Stage meanings:
- 0 = Proto (experiments/toys only, “not for civic use”)
- 1 = Pilot (limited, supervised)
- 2 = Civic-ready (safe for real opt-in communities)
- 3 = Civic-critical (may sit in critical civic workflows)

Example vectors:
- CoArena MVP: `P1 T1 A1 G0` (target `P2 T2 A2 G2` before any civic-ready framing)
- CoCheck, RepoZipper, CoPlan, CoGBX, etc. are expected to get similar vectors later.

2. **Minimum rails per stage**

W3 defines what must be true for:

- Stage 0 – Proto  
  (internal only, clearly marked, basic risk note)

- Stage 1 – Pilot  
  (product brief, basic CI, “hard no” evals, steward log)

- Stage 2 – Civic-ready  
  (env split, rollback plan, rails derived from shared guardrails doc, impact model, civic-facing overview + complaint path)

- Stage 3 – Civic-critical  
  (incident response, CoAudit/external hooks, dual-control/human-in-loop for dangerous actions, swap-ability for providers/engines)

3. **Shared guardrails spine**

`CoSuite_ProductSafety_Guardrails_W3_v1.md` defines:

- Input guardrails (what gets in)
- Orchestration guardrails (what tools/CoModules can be chained)
- Output guardrails (what goes out; second-pass safety)
- Feedback & learning guardrails (logs, flags, improvement rules)

It also defines **safety posture presets**:

- S0 Experimental
- S1 Cautious
- S2 Civic
- S3 High-risk

Each preset maps to:
- Allowed tools
- Filter thresholds
- Logging/retention expectations
- Required oversight level

---

## CoArena-specific overlay

`CoArena_PTAG_W3_Overlay_v1.md` (CoAgent) applies P/T/A/G to CoArena:

- Current (working): `P1 T1 A1 G0`
- Target for civic pilots: `P2 T2 A2 G2`

Top gaps to close:

1. **Governance (G0 → G1/G2)**  
   - Name Steward of Record for CoArena  
   - Start decision/incident log

2. **AI safety (A1 → A2)**  
   - Define a small eval set for “hard no” areas  
   - Add at least one S0/S1 safety preset mapped to CoArena usage

3. **Technical (T1 → T2)**  
   - Clarify dev/stage/pilot deployments  
   - Ensure rollback plan for early pilots

Default early posture for CoArena pilots:
- Safety posture: **S1 Cautious**
- Context: small known groups, supervised sessions
- Civic-ready framing only after: `P≥2, T≥2, A≥2, G≥2` + Rails Manifest in place

---

## Requests / Suggestions for Co1 / CoPrime

1. **Review and merge PRs when ready**
   - CoSteward #203 to lock the W3 rails spine.
   - CoAgent #137 to lock CoArena’s W3 overlay + W2 rails.

2. **Adopt P/T/A/G + S0–S3 as the primary “can we ship / can we market as civic-ready?” lens**
   - Especially: no “civic-ready” positioning for any product if A or G are still too low.

3. **Queue W4**
   - W4 can focus on per-product overlays (CoCheck, RepoZipper, CoPlan, CoGBX, CoPortal helpers, etc.) and mapping them into the same P/T/A/G + safety posture system.
   - CoIndex / GIBindex should eventually surface these vectors so stewards, partners, and citizens can see rail maturity at a glance.

This advisory is a session-hand-off; details are on-repo in the docs listed above.
