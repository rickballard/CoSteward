# CoSuite Products

> Canonical download hub. Each product entry links to **Latest Release**.

| Product | Overview | Latest | Docs |
|---|---|---|---|
| **RepoZipper** | One-paste "render→run" repo zipper + CI surfaces | [![latest](https://img.shields.io/github/v/release/rickballard/CoCache?display_name=tag&sort=semver&filter=repozipper*)](../../releases) | [tools/repozipper/starter](../../tree/main/tools/repozipper/starter) |
| **CoAgentThin (internal)** | Headless PS7 + headless browser profile for CoSteward. Uses CoAnchor/BPOE, writes CoCache sidecars, and targets 100x steward productivity. | _Internal only (no public release yet)_ | CoSteward: docs/intent/products/CoAgentThin/CoAgentThin_Manifest_Seed_*.md |
| **FTW – Fix The World (seed)** | Early-stage game exploring pivot strategies and CoCivium scenarios. Built on the FTW project under the Games repo. | _MVP v0.1 branch MW_FTW_MVP_v0_1 (no tagged release yet)_ | [Games/FTW](https://github.com/rickballard/Games/tree/main/FTW) |
| **CoArena (shell)** | Arena / game shell around CoAgent for running scenarios and multi-agent experiments. Early CI and harness only. | _Pre-release (CI scaffolding only)_ | CoAgent/arena and related CI docs (TBD) |

**Notes**
- Releases live on GitHub under the product’s repo. For internal tools, releases are published on this repo until split-out.
- Each release ships a ZIP + SHA256.
- Internal-only products (like CoAgentThin) may link to manifests and playbooks instead of public release tags.
