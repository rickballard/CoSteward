param(
    [int]$Count = 3,
    [switch]$CopyToClipboard
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function UTS {
    (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
}

$scriptRoot = $PSScriptRoot
$coPre      = Split-Path -Parent $scriptRoot
$rulesJson  = Join-Path $coPre 'docs\cocrux\CoCrux_Top50_v1_Placeholder.json'
$stateDir   = Join-Path $coPre '.state'
$stateFile  = Join-Path $stateDir 'CoPre_CoCruxState.json'

if (-not (Test-Path $rulesJson)) {
    throw "Rules JSON not found at '$rulesJson'. Run the CoPre CoCrux seed DO Block first."
}

$rules = Get-Content -Raw -Path $rulesJson | ConvertFrom-Json

if (-not $rules -or $rules.Count -lt 1) {
    throw "No CoCrux rules found in '$rulesJson'."
}

if ($Count -le 0) { $Count = 3 }
$rulesCount = $rules.Count

if (-not (Test-Path $stateDir)) {
    $null = New-Item -ItemType Directory -Path $stateDir -Force
}

if (-not (Test-Path $stateFile)) {
    $state = [pscustomobject]@{ Index = 0 }
} else {
    try {
        $state = Get-Content -Raw -Path $stateFile | ConvertFrom-Json
    } catch {
        $state = [pscustomobject]@{ Index = 0 }
    }
}

$start = [int]$state.Index
if ($start -lt 0 -or $start -ge $rulesCount) {
    $start = 0
}

$indices = @()
for ($i = 0; $i -lt $Count; $i++) {
    $indices += (($start + $i) % $rulesCount)
}

$batch = $indices | ForEach-Object { $rules[$_] }

$newIndex = ($start + $Count) % $rulesCount
$state = [pscustomobject]@{ Index = $newIndex }
$state | ConvertTo-Json -Depth 3 | Set-Content -Path $stateFile -Encoding UTF8

$lines = @()
$utsNow = UTS

$lines += "# CoCrux Top 50 batch"
$lines += ""
$lines += "- UTS: $utsNow"
$lines += "- Count: $Count"
$lines += "- StartIndex: $start"
$lines += "- NextIndex: $newIndex"
$lines += ""

foreach ($r in $batch) {
    $lines += "Rule $($r.Number): $($r.Title)"
    $lines += $r.Summary
    $lines += ""
}

$text = $lines -join [Environment]::NewLine

if ($CopyToClipboard) {
    try {
        $text | Set-Clipboard
        Write-Host "Copied CoCrux batch to clipboard." -ForegroundColor Green
    } catch {
        Write-Host "Could not copy to clipboard: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

$text
