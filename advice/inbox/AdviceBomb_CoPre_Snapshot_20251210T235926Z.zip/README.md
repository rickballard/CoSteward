# CoPre (local placeholder v0.3)

Local only placeholder for CoPre prompts.

- Seeded by CoPre_InitLocalRepo_FromPlaceholder_v1 at 20251210T220728Z
- Contains CoAgent shell pack at:
  - docs/prompts/coagent/CoAgent_Rick_InternalShellPack_v1.md

When a canonical CoPre repo exists on GitHub, you can:
- add it as a remote, and
- push this history.
