# CoAgent for rick - CoPre Prompt Shell Pack v1

> Status: draft v1 seeded by CoPre_Bootstrap_CoAgentRickShellPack_v1 at 20251210T212550Z
> Rails: CoAnchor Quickstart (Thin v6), BPOE, repo-first, PS7 DO Blocks only.

---

## Shell 1 - CoAgent internal pod / harness work

**Use when:** evolving PS7 tools, harness panels, or local OE for rick's CoAgent pod.

### Header (paste and tweak)

- Session label: CoAgentRick_InternalHarness_«YYYYMMDD»
- Wave: MW«n»/≈«N» (CoAgent lane)
- Intent: Evolve CoAgent internal pod to reduce rick's startup time to seconds.
- Repos in play: CoSteward, CoCache, CoAgent (and others only if named).
- Rails:
  - repo-first, no manual edits where automation is possible
  - PS7 DO Blocks only
  - CoAnchor Quickstart Thin v6 respected
  - BPOE / CoBus / CoPrime handoffs when shipping

### Prompt body (template)

I am rick, working on my internal CoAgent pod (100x productivity companion).

Context:
- Current focus: «e.g., wire PS7 layout to CoAgent harness panels»
- Relevant ProductCard: CoAgent_Rick_Internal_ProductCard_v1 (CoCache/docs/products)
- Products wave: W6 (Products_MegaWave_W6)

Please:
1. Propose a small set of PS7 DO Blocks I can run from my local OE.
2. Keep them aligned with CoAnchor Quickstart Thin v6 and BPOE.
3. Minimise my manual steps; assume I have a PS7 panel open in the right repo.
4. End with a short CoSync style recap that I can drop into CoSteward notes.

---

## Shell 2 - Products / W6 packaging work

**Use when:** working on W6 manifests, Products_MegaWave_W6, and public free MVP variant.

### Header (paste and tweak)

- Session label: Products_W6_CoAgentRick_«YYYYMMDD»
- Wave: MW«n»/≈«N» (Products lane)
- Intent: Wire CoAgent for rick into W6 and shape the public free MVP.
- Repos in play: CoCache (products), CoSteward (BPOE + CoBus), CoPre (prompts).
- Rails:
  - repo-first, PS7 DO Blocks only
  - no GLUKEY / HP57 content
  - public-safe products only in this lane

### Prompt body (template)

We are working in the Products lane on Wave W6.

Context:
- CoAgent for rick ProductCard lives at CoCache/docs/products/CoAgent_Rick_Internal_ProductCard_v1.md.
- W6 registry file exists and has an entry for this product.
- We want:
  - an internal pod for rick, and
  - a trimmed public free MVP ("CoAgent Home Seed").

Please:
1. Review the current ProductCard scope and W6 entry (I will paste them).
2. Suggest a minimal public MVP package that can be shipped free, safely.
3. Propose a Products_MegaWave_W6 step list to bundle this MVP as:
   - a GitHub template and/or
   - a downloadable starter zip.
4. Output concrete PS7 DO Blocks for CoCache and CoSteward to implement your plan.

---

## Footer (CoPre / BPOE reminder)

- Always:
  - run PS7 DO Blocks instead of hand editing where feasible
  - update CoBus / CoPrime notes when products scope changes
  - keep GLUKEY and HP57 content out of public lanes
- When in doubt:
  - write a short CoSync note in CoSteward
  - open a tiny branch plus PR instead of editing main.
