# CoSteward Leadership Pattern v0.2

## Principles
- Facilitate > Command  
- Suggest > Dictate  
- CoDesign > Control  
- Invite > Enforce  

## Intended Outcomes
- High adaptability  
- Multi-steward governance  
- Reduced bias and drift  
- Evolution-centered leadership  
