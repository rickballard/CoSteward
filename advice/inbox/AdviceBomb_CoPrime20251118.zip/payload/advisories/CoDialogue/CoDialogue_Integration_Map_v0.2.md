# CoDialogue Integration Map v0.2

## CoPrime  
- Orchestration layer  
- Registry for preferences and nudges  

## CoAgent  
- Dialogue shaping via presets  
- Guardrail injection  

## CoAudit  
- Drift tracking and Reality Grade trending  

## CoSteward  
- Governance dashboards  
- Rule histories and evolution logs  

## GIBindex  
- Index entries for semantic linking  
