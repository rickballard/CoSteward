# CoMind Communal Evolution (Full Version v3)

## CM0 CoSprout
Loose, dialogic cooperation.

## CM1 CoChord
Coordinated multi-agent teams.

## CM2 CoChoir
True telepathic-like mindshare.

## CM3 CoField
Field cognition: individual instances as projections of a unified cognitive field.
