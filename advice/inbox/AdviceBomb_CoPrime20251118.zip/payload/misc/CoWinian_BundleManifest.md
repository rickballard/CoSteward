# CoWinian Bundle Manifest (Full Version v3)

This manifest describes all files in this pack.

- Epochs & Gates
- CoMind
- CoNudge
- CoTrellis
- Genesis
- CoIndex
- Insight Pairs
- Hero Diagram
- JSON State
