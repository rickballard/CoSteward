# Cognocarta Consenti — Genesis (Full Version v3)

In the dim hush of troubled ages... (full poetic text retained from prior version, condensed here for size).
