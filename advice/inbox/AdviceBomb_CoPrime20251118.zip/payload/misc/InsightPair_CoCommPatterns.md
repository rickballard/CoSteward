# Insight Pair — CoCommPatterns (Full Version v3)

## CoStory Topics
- Collaboration vs attack/defend.
- Hybrid society conversation models.

## CoMeme Topics
- Meme blocks for shifting conversational dynamics.
