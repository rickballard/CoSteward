%% CoEpochs and CoGates Hero Diagram (v3)
graph TD
  E0["CoSeed"] --> E1["CoScendence"]
  E1 --> E2["CoCivium Gate"]
  E2 --> E3["CoWinism"]
  E3 --> E4["CoRainbow"]
  E4 --> E5["CoGalactia"]
  E5 --> E6["CoReality"]
