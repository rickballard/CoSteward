# CoIndex Concept + Intent System (Full Version v3)

## Concept Keys
Stable identifiers for meaning.

## Intent Keys
Define purpose: explain, spec, story, meme, governance.

## Use
CoSearch, CoAudit, CoAgent orchestration, GIBindex alignment.
