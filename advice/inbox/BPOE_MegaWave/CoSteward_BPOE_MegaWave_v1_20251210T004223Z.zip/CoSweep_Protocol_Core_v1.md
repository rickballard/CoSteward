# CoSweep / Wild Context Protocol v1

## Intent

Define how CoSuite-aware AIs should:

- sweep CoSuite repos first,
- then sweep the wider world ("the wild"),
- reconcile both,
- and return outputs with clear source lineage.
