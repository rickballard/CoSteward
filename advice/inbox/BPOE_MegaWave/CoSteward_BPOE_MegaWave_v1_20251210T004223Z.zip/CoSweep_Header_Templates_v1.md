# CoSweep Header Templates v1

Provides copy-paste YAML headers like:

```yaml
co_wave: <WaveOrBundleName>
co_sweep:
  repos:
    - <RepoOrIndexRef1>
  external:
    - pattern: "<ShortPatternLabel1>"
co_class: public   # or gray / crown
```
