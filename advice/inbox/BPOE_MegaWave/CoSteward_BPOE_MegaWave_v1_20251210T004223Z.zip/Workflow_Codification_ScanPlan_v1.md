# Workflow Codification Scan Plan v1

- Inventory DO-blocks, CI workflows, guard scripts across CoSuite repos.
- Cluster by function (session rescue, inbox, metrics, onboarding, etc.).
- Extract and document canonical patterns; mark legacy/experimental flows.
